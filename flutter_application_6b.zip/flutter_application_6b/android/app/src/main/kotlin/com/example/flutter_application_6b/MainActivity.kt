package com.example.flutter_application_6b

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
